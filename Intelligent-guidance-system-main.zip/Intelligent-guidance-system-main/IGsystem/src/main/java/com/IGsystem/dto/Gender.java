package com.IGsystem.dto;

public enum Gender {
    male,
    female,
    other
}
