package com.IGsystem.dto;

public enum Occupation {
    student,
    teacher,
    other
}
