package com.IGsystem.service.Imp;

import com.IGsystem.dto.Question;
import com.IGsystem.dto.Result;
import com.IGsystem.mapper.QuestionMapper;
import com.IGsystem.service.QuestionService;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpSession;
import java.util.List;

@Service
@Slf4j
public class QuestionServiceImp extends ServiceImpl<QuestionMapper,Question> implements QuestionService {
    @Override
    public Result get(HttpSession session) {
        //TODO 获得问题
        //创建随机抽取的wrapper
         QueryWrapper<Question> wrapper = new QueryWrapper<>();
         wrapper.last("LIMIT 5");
         List<Question> questions = baseMapper.selectList(wrapper);
         // 返回结果
         if (!questions.isEmpty()) {
             return Result.ok(questions);
         } else {
             return Result.fail("没有找到问题");
         }
    }
}
