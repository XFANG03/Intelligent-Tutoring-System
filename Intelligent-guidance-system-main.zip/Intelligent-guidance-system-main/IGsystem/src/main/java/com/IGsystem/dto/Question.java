package com.IGsystem.dto;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

@Data
@TableName("algebra")
public class Question {
    private Long ProblemId;
    private String problem;
    private String level;
    private String type;
    private String solution;
    private Integer mathId;
}
