package com.IGsystem.dto;

import lombok.Data;

@Data
public class LoginFormDTO {
    private String phone;
    private String password;
}
