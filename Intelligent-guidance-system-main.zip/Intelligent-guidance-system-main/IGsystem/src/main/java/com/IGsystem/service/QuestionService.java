package com.IGsystem.service;

import com.IGsystem.dto.LoginFormDTO;
import com.IGsystem.dto.Question;
import com.IGsystem.dto.Result;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpSession;


public interface QuestionService {
    Result get(HttpSession session);
}
