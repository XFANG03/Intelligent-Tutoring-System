package com.IGsystem.controller;


import com.IGsystem.dto.Question;
import com.IGsystem.dto.RegisterFormDTO;
import com.IGsystem.dto.Result;
import com.IGsystem.service.QuestionService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author Flora_YangFY
 * @since 2024-3-4
 */

@RestController
@RequestMapping("/question")
@CrossOrigin(origins = "*") // 允许所有域名的请求
@Slf4j
public class QuestionController {

    @Resource
    private QuestionService questionService;

    @PostMapping("/get")
    public Result getQuestion(HttpSession session){
        return questionService.get(session);
    }
}
