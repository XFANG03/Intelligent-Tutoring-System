package com.IGsystem.mapper;

import com.IGsystem.dto.Question;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface QuestionMapper extends BaseMapper<Question> {
}
