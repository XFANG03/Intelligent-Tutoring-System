# Intelligent-guidance-system
### 项目信息
项目名称：智能导学系统
### 项目页面
- 功能页面
1. 用户完成登录/注册后的第一个页面，上半部分是科目滑动栏，下半部分是历史记录栏
![图片](https://github.com/Flora-0221/Intelligent-guidance-system/assets/113693673/873fc82b-2afa-4d52-9df1-23851aa0356a)
2. 用户点击科目滑动栏中的start，进入下面的homework界面，左半部分显示homework的数量和相关信息，右半部分显示用户在该科目下的历史正确率
![图片](https://github.com/Flora-0221/Intelligent-guidance-system/assets/113693673/94bf60c7-07c2-4b77-8a06-0fbcd622e24e)
4. 用户点击homework后，进入做题界面
![图片](https://github.com/Flora-0221/Intelligent-guidance-system/assets/113693673/930aafcd-8c50-463a-9815-6be64219f74c)
5. 用户将所有题目都完成后，跳出得分弹窗，然后进入总结界面。在总结界面中，用户可以点击题目编号来进一步的查看题目解析和其他同学在本题上的正确率
![图片](https://github.com/Flora-0221/Intelligent-guidance-system/assets/113693673/b1f0b9cc-4e7e-4d10-bf73-1fc666b4b760)
![图片](https://github.com/Flora-0221/Intelligent-guidance-system/assets/113693673/018542b7-3fd0-4d40-ac74-89b0d1692349)

- 用户信息界面
![图片](https://github.com/Flora-0221/Intelligent-guidance-system/assets/113693673/10d514fa-071e-400c-bec6-960ce8807a13)
![图片](https://github.com/Flora-0221/Intelligent-guidance-system/assets/113693673/a0b22b0d-6144-4c8c-810d-c8c2af314644)
![图片](https://github.com/Flora-0221/Intelligent-guidance-system/assets/113693673/4af9e2d4-74db-460f-be36-9c12879ab6dd)

- 登录前的展示主页

滑动呈现
![图片](https://github.com/Flora-0221/Intelligent-guidance-system/assets/113693673/c6a5800a-bc24-41b8-b7d6-d80288e9d1e3)


- 登录和注册界面
![图片](https://github.com/Flora-0221/Intelligent-guidance-system/assets/113693673/f24ba6d6-ded5-4408-b93d-f5654994f170)
![图片](https://github.com/Flora-0221/Intelligent-guidance-system/assets/113693673/1adefb9b-2212-4999-9309-9ea11bc64242)

