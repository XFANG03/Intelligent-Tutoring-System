new Vue({
    el: "#panel2",
    data() {
        return {
            editableTabsValue: '2',
            editableTabs: [{
                title: 'Tab 1',
                name: '1',
                content: 'Tab 1 content'
            }, {
                title: 'Tab 2',
                name: '2',
                content: 'Tab 2 content'
            }],
            tabIndex: 2,
            currentPage4: 4,
            tableData: [{
                date: '2016-05-03',
                name: '语文',
                address: '比喻的作用'
            }, {
                date: '2016-05-02',
                name: '英语',
                address: 'He is busy _ something'
            }, {
                date: '2016-05-04',
                name: '数学',
                address: '2x+1=7'
            }, {
                date: '2016-05-01',
                name: '政治',
                address: '中国的政体是？'
            }, {
                date: '2016-05-08',
                name: '历史',
                address: '清朝建立时间'
            }, {
                date: '2016-05-06',
                name: '地理',
                address: '中国的气候是？'
            }, {
                date: '2016-05-07',
                name: '生物',
                address: '分子生物学的研究内容主要包含？'
            }]
        }
    },
    methods: {
        addTab(targetName) {
            let newTabName = ++this.tabIndex + '';
            this.editableTabs.push({
                title: 'New Tab',
                name: newTabName,
                content: 'New Tab content'
            });
            this.editableTabsValue = newTabName;
        },
        removeTab(targetName) {
            let tabs = this.editableTabs;
            let activeName = this.editableTabsValue;
            if (activeName === targetName) {
                tabs.forEach((tab, index) => {
                    if (tab.name === targetName) {
                        let nextTab = tabs[index + 1] || tabs[index - 1];
                        if (nextTab) {
                            activeName = nextTab.name;
                        }
                    }
                });
            }

            this.editableTabsValue = activeName;
            this.editableTabs = tabs.filter(tab => tab.name !== targetName);
        }, handleSizeChange(val) {
            console.log(`每页 ${val} 条`);
        },
        handleCurrentChange(val) {
            console.log(`当前页: ${val}`);
        }
    }

})
