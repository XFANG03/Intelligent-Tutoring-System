new Vue({
    el: "#panel6",
    data() {
        return {
            multipleSelection: [],
            counts: 0,
            page: 1,
            pageSize: 10,
            loading: true,
            user: {},
            text: []
        }
    },
    beforeMount() {
        this.fetchUserInfo();

    },
    mounted() {
        this.init();
    },
    computed: {
        formatteddate() {
            return function (row) {
                const date = new Date(row.recordTime);
                const year = date.getFullYear();
                const month = (date.getMonth() + 1).toString().padStart(2, '0');
                const day = date.getDate().toString().padStart(2, '0');
                return `${year}-${month}-${day}`;
            };
        },
    },
    methods: {
        filterHandler(value, row, column) {
            const formattedValue = this.formatMode(row, column);
            return formattedValue === value;
        },
        async init() {
            try {
                const data = {
                    page: this.page,
                    pageSize: this.pageSize
                };

                const res = await axios.post('/user/users/page', data);
                console.log(res.data)
                if (String(res.data.code) === '1') {
                    this.text = res.data.data.records || [];
                    this.counts = res.data.data.total;
                }
            } catch (error) {
                this.$message.error('请求出错了：' + error);
            }
        },
        handleSizeChange(val) {
            this.pageSize = val
            this.init()
        },
        handleCurrentChange(val) {
            this.page = val
            this.init()
        },
        toggleSelection(rows) {
            if (rows) {
                rows.forEach(row => {
                    this.$refs.multipleTable.toggleRowSelection(row);
                });
            } else {
                this.$refs.multipleTable.clearSelection();
            }
        },
        handleSelectionChange(val) {
            this.multipleSelection = val;
        },
        async handleDeleteSelection() {
            const selectedRows = this.multipleSelection; // 获取选中的行数据
            // 遍历选中的行数据，逐个发送删除请求
            try {
                for (const row of selectedRows) {
                    const res = await axios.post('/user/users/delete', row);
                    console.log(res.data);
                }
                this.init(); // 删除完成后进行页面数据初始化操作
                this.$message.success('Delete successful!');
            } catch (error) {
                console.error(error);
                this.$message.error('Delete failed: ' + error.message);
            }
        },
        async handleDelete(row) {
            try {
                const res = await axios.post('/user/users/delete', row); // 发送包含整个对象的 POST 请求
                console.log(res.data); // 输出后端返回的数据
                this.$message.success('Delete successful!');
                this.init();
            } catch (error) {
                console.error(error);
            }
        },
        async fetchUserInfo() {
            const _this = this;
            try {
                const response = await fetch('/user/users/searchuser', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    }
                });
                if (response.ok) {
                    const result = await response.json(); // 解析返回的 JSON 字符串为 JavaScript 对象
                    if (result.code === 1) {
                        console.log(JSON.parse(result.data))
                        _this.user = JSON.parse(result.data);
                        _this.loading = false;
                    } else if (result.code === 0) {
                        window.location.href = './index.html'
                    }
                    else {
                        _this.loading = false;
                        throw new Error('Failed to fetch user info.');
                    }
                }
                else {
                    _this.loading = false;
                    throw new Error('Network response was not ok.');
                }
            } catch (error) {
                _this.loading = false;
                console.error(error);
            }
        },
        formatter(row, column) {
            return row[column.property];
        },
        formatText(row, column) {
            const text = row[column.property];
            if (text.length > 50) {
                return text.substring(0, 50) + "...";  // 如果文本长度超过10个字符，只显示前10个字符并加上省略号
            } else {
                return text;
            }
        },
        formatMode(row, column) {
            let mode = row[column.property];
            let modeText = '';
            if (typeof mode === 'string' && !isNaN(parseInt(mode))) {
                // 如果 mode 是字符串且可以转换为数字，则将其转换为数字类型
                mode = parseInt(mode);
            } else {
                // 如果无法转换为数字，则给出相应的提示或默认处理
                console.warn('Invalid mode value: ' + mode);
                return 'Unknown Mode';
            }
            switch (mode) {
                case 0:
                    modeText = 'Didn\'t choose';
                    break;
                case 1:
                    modeText = 'World Cloud';
                    break;
                case 2:
                    modeText = 'Keyword';
                    break;
                case 3:
                    modeText = 'Abstract';
                    break;
                case 4:
                    modeText = 'Sentiment';
                    break;
                case 5:
                    modeText = 'NewsTopic';
                    break;
                case 6:
                    modeText = 'Fake News Detection';
                    break;
                default:
                    modeText = 'Unknown Mode';
            }
            return modeText;
        },
    }
})
