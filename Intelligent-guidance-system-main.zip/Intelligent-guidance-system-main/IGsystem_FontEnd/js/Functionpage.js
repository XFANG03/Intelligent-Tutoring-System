Vue.createApp({
    data() {
        return {
            options: [
                {
                    content: '操作一',
                    value: 1,
                },
                {
                    content: '操作二',
                    value: 2,
                },
                {
                    content: '操作三',
                    value: 3,
                    disabled: true,
                },
                {
                    content: '操作四',
                    value: 4,
                    disabled: true,
                },
            ],
            title: "History",
            infoMessage: "test",
            mode: 1,
            translateX: 0,
            distance: 100,
            cards: [
                { title: 'Card 1', percentage: 50, footerText: '70', options: [] },
                { title: 'Card 2', percentage: 75, footerText: '80', options: [] },
                { title: 'Card 2', percentage: 75, footerText: '80', options: [] },
                { title: 'Card 2', percentage: 75, footerText: '80', options: [] },
                // Add more card objects as needed
            ],
            options: [
                {
                    content: '操作一',
                    value: 1,
                },
                {
                    content: '操作二',
                    value: 2,
                },
            ],
            subjects: [
                { name: 'Math', introduce: '数学 [英语：mathematics，源自古希腊语μάθημα（máthēma）；经常被缩写为math或maths]，是... '},
                { name: 'English', introduce: '英语（English）属于 印欧语系 日耳曼语族 西日耳曼语支 ，最早被 中世纪 的 英国 使用，...' },
                { name: 'Chinese', introduce: '语文是一个多义词，通常作为语言文字、语言文学、语言文化的简称，其本义为“语言文字”。' },
                { name: 'Physics', introduce: '物理学（physics），是研究物质最一般的运动规律和物质基本结构的学科。作为自然科学的带头学科，' },
                { name: 'Physics', introduce: '物理学（physics），是研究物质最一般的运动规律和物质基本结构的学科。作为自然科学的带头学科，' },
            ],
            activeBox: null,
        }
    },

    methods: {
        onError(params) {
            console.log(params);
        },
        leftBox() {
            if (this.mode < this.subjects.length - 1) {
                this.mode = (Math.abs(this.mode + 1)) % this.subjects.length;
                this.translateX -= this.distance;
            }
        },
        rightBox() {
            if (this.mode > 0) {
                this.mode = (Math.abs(this.mode - 1)) % this.subjects.length;
                this.translateX += this.distance;
            }
        },
        calculateMode() {
            this.mode = Math.floor(this.subjects.length / 2);
        },
        calculateDistance() {
            console.log("function start");
            //数组
            if (this.$refs.subjects) {
                const subjects = this.$refs.subjects;
                const rect1 = subjects[this.mode].getBoundingClientRect();
                const rect2 = subjects[this.mode + 1].getBoundingClientRect();
                const midpoint1 = rect1.left + (rect1.width / 2);
                const midpoint2 = rect2.left + (rect2.width / 2);
                this.distance = (midpoint2 - midpoint1);
            }
            else {
                console.log("no define");
            }
        }
    },
    mounted() {
        this.calculateMode();
        this.calculateDistance();
    }


}).use(TDesign).mount('#app');
